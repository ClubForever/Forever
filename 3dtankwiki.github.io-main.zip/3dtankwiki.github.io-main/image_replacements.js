const imageReplacementDict = {
    
};
